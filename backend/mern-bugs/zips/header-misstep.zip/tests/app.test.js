const request = require('supertest');
const app = require('../src/index');
test('returns json content type', async () => {
  const res = await request(app).get('/status');
  expect(res.headers['content-type']).toMatch(/json/);
});
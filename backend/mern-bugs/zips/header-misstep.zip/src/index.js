const express = require('express');
const app = express();
app.get('/status', (req, res) => {
  res.send('{"status": "ok"}'); // BUG: Sending string without JSON content-type
});
module.exports = app;
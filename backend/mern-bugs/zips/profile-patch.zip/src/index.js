const express = require('express');
const app = express();
app.use(express.json());
let user = { id: 1, name: 'Alice', bio: 'Hello' };
app.patch('/profile', (req, res) => {
  user = { ...req.body }; // BUG: Replaces entire object, losing ID
  res.json(user);
});
module.exports = app;
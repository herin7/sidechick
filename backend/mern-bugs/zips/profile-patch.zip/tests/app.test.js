const request = require('supertest');
const app = require('../src/index');
test('preserves user ID on patch', async () => {
  const res = await request(app).patch('/profile').send({ name: 'Bob' });
  expect(res.body.id).toBe(1);
});
const request = require('supertest');
const app = require('../src/index');
test('denies access without header', async () => {
  const res = await request(app).get('/data');
  expect(res.status).toBe(403);
});
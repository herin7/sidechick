const express = require('express');
const app = express();
const auth = (req, res, next) => {
  if (req.headers.auth === 'secret') next();
  else res.status(403).send('Forbidden');
};
app.get('/data', (req, res) => res.json({ msg: 'Success' })); // BUG: Route defined before middleware
app.use(auth);
module.exports = app;
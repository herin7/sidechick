const request = require('supertest');
const app = require('../src/index');
test('finishes response on delete', async () => {
  const res = await request(app).delete('/item/1');
  expect(res.status).toBe(204);
});
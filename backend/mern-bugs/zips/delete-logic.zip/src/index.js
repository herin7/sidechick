const express = require('express');
const app = express();
app.delete('/item/:id', (req, res) => {
  if (req.params.id === '1') {
    res.status(204); // BUG: Missing .send() or .end() to finish response
  } else {
    res.status(404).end();
  }
});
module.exports = app;
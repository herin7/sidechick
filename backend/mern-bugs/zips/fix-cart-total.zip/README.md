# Fix Cart Total
Expected total: 25. Actual bug is ignoring quantities.
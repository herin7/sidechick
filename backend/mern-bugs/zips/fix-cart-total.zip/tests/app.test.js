const request = require('supertest');
const app = require('../src/index');
test('calculates correct total with quantities', async () => {
  const res = await request(app).get('/cart/total');
  expect(res.body.total).toBe(25);
});
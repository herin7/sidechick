const express = require('express');
const app = express();
app.use(express.json());
const cart = { items: [{ id: 1, price: 10, qty: 2 }, { id: 2, price: 5, qty: 1 }] };
app.get('/cart/total', (req, res) => {
  const total = cart.items.reduce((acc, item) => acc + item.price, 0); // BUG: missing qty
  res.json({ total });
});
module.exports = app;
const request = require('supertest');
const app = require('../src/index');
test('rejects empty email', async () => {
  const res = await request(app).post('/register').send({ email: '' });
  expect(res.status).toBe(400);
});
test('rejects email without domain', async () => {
  const res = await request(app).post('/register').send({ email: 'test@' });
  expect(res.status).toBe(400);
});
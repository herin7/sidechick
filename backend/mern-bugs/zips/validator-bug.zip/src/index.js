const express = require('express');
const app = express();
app.use(express.json());
app.post('/register', (req, res) => {
  const { email } = req.body;
  if (email && email.includes('@')) { // BUG: Too simple validation
    res.json({ ok: true });
  } else {
    res.status(400).json({ error: 'Invalid' });
  }
});
module.exports = app;
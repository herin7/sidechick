const request = require('supertest');
const app = require('../src/index');
test('returns list of users', async () => {
  const res = await request(app).get('/users');
  expect(Array.isArray(res.body)).toBe(true);
});
const express = require('express');
const app = express();
const db = { getUsers: () => Promise.resolve([{ id: 1, name: 'John' }]) };
app.get('/users', async (req, res) => {
  const users = db.getUsers(); // BUG: missing await
  res.json(users);
});
module.exports = app;
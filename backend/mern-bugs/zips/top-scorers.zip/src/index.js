const express = require('express');
const app = express();
const scores = [100, 90, 80, 70, 60];
app.get('/top3', (req, res) => {
  res.json(scores.slice(0, 2)); // BUG: should be 3
});
module.exports = app;
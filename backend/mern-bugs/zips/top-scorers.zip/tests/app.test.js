const request = require('supertest');
const app = require('../src/index');
test('returns top 3 scores', async () => {
  const res = await request(app).get('/top3');
  expect(res.body.length).toBe(3);
});
const request = require('supertest');
const app = require('../src/index');
test('returns 200 on success', async () => {
  const res = await request(app).post('/login').send({ user: 'admin', pass: '123' });
  expect(res.status).toBe(200);
});
const express = require('express');
const app = express();
app.use(express.json());
app.post('/login', (req, res) => {
  const { user, pass } = req.body;
  if (user === 'admin' && pass === '123') {
    res.status(201).json({ token: 'abc' }); // BUG: Wrong status code, should be 200
  } else {
    res.status(401).send('Unauthorized');
  }
});
module.exports = app;
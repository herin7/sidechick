const request = require('supertest');
const app = require('../src/index');
test('returns data inside metadata key', async () => {
  const res = await request(app).get('/api/info');
  expect(res.body.metadata.name).toBe('app');
});
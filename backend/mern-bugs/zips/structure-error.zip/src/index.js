const express = require('express');
const app = express();
app.get('/api/info', (req, res) => {
  res.json({ name: 'app', version: '1.0' }); // BUG: expected nested metadata
});
module.exports = app;
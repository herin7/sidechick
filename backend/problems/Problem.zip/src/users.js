const users = [
  { id: 1, name: "Alice Johnson", email: "alice@example.com", role: "Engineer" },
  { id: 2, name: "Bob Martinez", email: "bob@example.com", role: "Designer" },
  { id: 3, name: "Carol White", email: "carol@example.com", role: "Manager" },
  { id: 4, name: "David Kim", email: "david@example.com", role: "Engineer" },
  { id: 5, name: "Eva Patel", email: "eva@example.com", role: "Analyst" },
  { id: 6, name: "Frank Lee", email: "frank@example.com", role: "Engineer" },
  { id: 7, name: "Grace Liu", email: "grace@example.com", role: "Designer" },
  { id: 8, name: "Henry Brown", email: "henry@example.com", role: "Manager" },
  { id: 9, name: "Isla Clarke", email: "isla@example.com", role: "Analyst" },
  { id: 10, name: "Jake Wilson", email: "jake@example.com", role: "Engineer" },
  { id: 11, name: "Karen Scott", email: "karen@example.com", role: "Designer" },
  { id: 12, name: "Liam Adams", email: "liam@example.com", role: "Engineer" },
  { id: 13, name: "Mia Turner", email: "mia@example.com", role: "Analyst" },
  { id: 14, name: "Noah Harris", email: "noah@example.com", role: "Manager" },
  { id: 15, name: "Olivia Young", email: "olivia@example.com", role: "Engineer" },
  { id: 16, name: "Paul Walker", email: "paul@example.com", role: "Designer" },
  { id: 17, name: "Quinn Hall", email: "quinn@example.com", role: "Analyst" },
  { id: 18, name: "Rose Allen", email: "rose@example.com", role: "Engineer" },
  { id: 19, name: "Sam Green", email: "sam@example.com", role: "Manager" },
  { id: 20, name: "Tina Baker", email: "tina@example.com", role: "Engineer" },
];

export default users;

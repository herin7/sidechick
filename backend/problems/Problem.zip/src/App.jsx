import { useState, useEffect } from "react";
import allUsers from "./users";
import "./App.css";

const PAGE_SIZE = 5;

function UserList({ users }) {
  return (
    <ul className="user-list">
      {users.map((user) => (
        <li key={user.id} className="user-card">
          <div className="user-avatar">{user.name.charAt(0)}</div>
          <div className="user-info">
            <span className="user-name">{user.name}</span>
            <span className="user-email">{user.email}</span>
            <span className="user-role">{user.role}</span>
          </div>
        </li>
      ))}
    </ul>
  );
}

export default function App() {
  const [currentPage, setCurrentPage] = useState(0);
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    setLoading(true);

    setTimeout(() => {
      const start = currentPage;
      const end = start + PAGE_SIZE;
      const pageUsers = allUsers.slice(start, end);
      setUsers(pageUsers);
      setLoading(false);
    }, 300);
  }, [currentPage]);

  const totalPages = Math.ceil(allUsers.length / PAGE_SIZE);

  const handlePrev = () => {
    setCurrentPage((prev) => Math.max(prev - 1, 1));
  };

  const handleNext = () => {
    setCurrentPage((prev) => Math.min(prev + 1, totalPages));
  };

  return (
    <div className="app">
      <header className="app-header">
        <h1>User Directory</h1>
        <p className="subtitle">Browse all registered users</p>
      </header>

      <main className="app-main">
        {loading ? (
          <div className="loading">Loading users…</div>
        ) : users.length === 0 ? (
          <div className="empty">No users found.</div>
        ) : (
          <UserList users={users} />
        )}

        <div className="pagination">
          <button
            className="page-btn"
            onClick={handlePrev}
            disabled={currentPage === 1}
          >
            ← Prev
          </button>

          <span className="page-indicator">
            Page {currentPage} of {totalPages}
          </span>

          <button
            className="page-btn"
            onClick={handleNext}
            disabled={currentPage === totalPages}
          >
            Next →
          </button>
        </div>
      </main>
    </div>
  );
}

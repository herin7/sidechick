# 🐛 User Directory — Interview Challenge

A small React app that fetches and paginates a list of users.  
Your job: **find and fix the bugs**.

---

## Getting Started

```bash
npm install
npm run dev
```

Open `http://localhost:5173` and interact with the app.  
Something feels off. Can you tell what?

---

## The Challenge

This codebase has **3 bugs** hidden in plain sight. They are not syntax errors — the app runs, but it misbehaves.

Your task:
1. **Identify** each bug
2. **Explain** what it causes
3. **Fix** it

---

## Hints (indirect)

> These are starting points — not answers. Read carefully.

### 🔍 Hint 1 — Data feels... shifted?
Open `src/App.jsx` and look at how the visible users are calculated before being passed to the list.  
Think about what page 1 *should* show vs what it *actually* shows.  
The answer lies somewhere between `PAGE_SIZE` and the slice arguments.

### 🔍 Hint 2 — React is watching the wrong things
Still in `src/App.jsx` — check the `useEffect`.  
React's dep array tells React *when* to re-run the effect.  
Ask yourself: is everything the effect *depends on* actually listed there?  
What happens when something changes that React doesn't know to watch?

### 🔍 Hint 3 — State starts somewhere
Look at the very first `useState` call in `App.jsx`.  
Think about what the correct initial value should be for a page counter.  
Then trace through what the UI renders and what buttons are enabled on the very first load.

---

## Files to Focus On

| File | Why it matters |
|------|----------------|
| `src/App.jsx` | All 3 bugs live here |
| `src/users.js` | Understand the shape and length of the data |

> The `src/` folder is all you need. No other files are involved in the bugs.

---

## What a Good Fix Looks Like

- Each fix should be **1–3 lines** of code at most
- After fixing, pagination should display the correct users per page, page numbers should be accurate, and the Prev button should be correctly disabled on page 1

---

## Constraints

- No TypeScript
- No external libraries beyond React
- Keep changes minimal and surgical

---

*Good luck. The bugs are subtle — that's the point.*
